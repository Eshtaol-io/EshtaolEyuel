package com.testsigma.automator.actions.mobile.android.ifconditional;


import com.testsigma.automator.actions.mobile.android.verify.VerifyTitleContainsAction;

public class TitleContainsAction extends VerifyTitleContainsAction {
}
