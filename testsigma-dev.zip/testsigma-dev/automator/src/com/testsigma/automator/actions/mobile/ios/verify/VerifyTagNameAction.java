package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyTagNameAction extends com.testsigma.automator.actions.web.verify.VerifyTagNameAction {
}
