package com.testsigma.automator.actions.mobile.ios.wait;

public class WaitUntilAlertAbsentAction extends com.testsigma.automator.actions.web.wait.WaitUntilAlertAbsentAction {
}
