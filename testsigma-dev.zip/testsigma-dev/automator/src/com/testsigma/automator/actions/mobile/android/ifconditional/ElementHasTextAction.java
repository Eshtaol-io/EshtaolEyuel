package com.testsigma.automator.actions.mobile.android.ifconditional;


import com.testsigma.automator.actions.mobile.android.verify.VerifyTextSnippet;

public class ElementHasTextAction extends VerifyTextSnippet {
}
