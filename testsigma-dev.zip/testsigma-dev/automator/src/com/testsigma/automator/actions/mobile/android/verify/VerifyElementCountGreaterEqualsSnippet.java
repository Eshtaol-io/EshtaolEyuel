package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.web.verify.VerifyElementsCountGreaterOrEqualsAction;

public class VerifyElementCountGreaterEqualsSnippet extends VerifyElementsCountGreaterOrEqualsAction {
}
