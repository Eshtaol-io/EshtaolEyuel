package com.testsigma.automator.actions.mobile.android.switchactions;

import com.testsigma.automator.actions.mobile.switchactions.MobileNativeSwitchToNativeAppAction;

public class SwitchToNativeAppContextAction extends MobileNativeSwitchToNativeAppAction {

}
