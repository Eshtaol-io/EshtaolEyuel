package com.testsigma.automator.actions.mobile.ios.coordinates;

import com.testsigma.automator.actions.mobile.tap.MobileNativeTapCoordinatesSnippet;

public class TapOnCoordinatesAction extends MobileNativeTapCoordinatesSnippet {
}
