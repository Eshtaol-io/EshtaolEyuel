package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.mobile.mobileweb.verify.VerifyDisabledAction;

public class VerifyDisabledSnippet extends VerifyDisabledAction {
}
