package com.testsigma.automator.actions.mobile.android.wait;

import com.testsigma.automator.actions.web.wait.WaitUntilElementIsClickableAction;

public class WaitUntilElementIsClickableSnippet extends WaitUntilElementIsClickableAction {
}
