package com.testsigma.automator.actions.mobile.ios.alert;

public class VerifyAlertAbsenceAction extends com.testsigma.automator.actions.web.verify.VerifyAlertAbsenceAction {
}
