package com.testsigma.automator.actions.mobile.ios.generic;

import com.testsigma.automator.actions.mobile.MobileNativeOrientationPortraitSnippet;

public class SetOrientationToPortraitAction extends MobileNativeOrientationPortraitSnippet {
}
