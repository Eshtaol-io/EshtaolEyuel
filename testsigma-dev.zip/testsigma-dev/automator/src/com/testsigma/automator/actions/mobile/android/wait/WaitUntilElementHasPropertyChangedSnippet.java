package com.testsigma.automator.actions.mobile.android.wait;

import com.testsigma.automator.actions.mobile.mobileweb.wait.WaitUntilElementHasPropertyChangedAction;

public class WaitUntilElementHasPropertyChangedSnippet extends WaitUntilElementHasPropertyChangedAction {
}
