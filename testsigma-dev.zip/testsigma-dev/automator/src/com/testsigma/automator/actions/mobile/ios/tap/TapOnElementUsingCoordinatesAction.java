package com.testsigma.automator.actions.mobile.ios.tap;

public class TapOnElementUsingCoordinatesAction extends com.testsigma.automator.actions.mobile.tap.TapOnElementUsingCoordinatesAction {
}
