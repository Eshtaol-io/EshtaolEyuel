package com.testsigma.automator.actions.mobile.ios.generic;

public class DragAndDropAction extends com.testsigma.automator.actions.mobile.generic.DragAndDropAction {
}
