package com.testsigma.automator.actions.mobile.android.verify;

public class VerifyIfAppInstalledAction extends com.testsigma.automator.actions.mobile.verify.VerifyIfAppInstalledAction {
}
