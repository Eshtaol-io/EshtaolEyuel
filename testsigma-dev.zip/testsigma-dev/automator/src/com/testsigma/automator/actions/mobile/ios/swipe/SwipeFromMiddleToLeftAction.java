package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromMiddleToLeftAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeMiddleToLeftSnippet {
}
