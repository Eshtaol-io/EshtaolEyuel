package com.testsigma.automator.actions.mobile.android.alert;

import com.testsigma.automator.actions.mobile.mobileweb.generic.DismissAlertAction;

public class DismissAlertSnippet extends DismissAlertAction {
}
