package com.testsigma.automator.actions.mobile.ios.wait;

public class WaitUntilElementPropertyChangedAction extends com.testsigma.automator.actions.web.wait.WaitUntilElementPropertyChangedAction {
}
