package com.testsigma.automator.actions.mobile.android.click;

public class ClickSnippet extends com.testsigma.automator.actions.mobile.tap.MobileNativeClickSnippet {
}
