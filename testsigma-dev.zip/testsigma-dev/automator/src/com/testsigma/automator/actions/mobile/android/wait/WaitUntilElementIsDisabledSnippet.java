package com.testsigma.automator.actions.mobile.android.wait;

import com.testsigma.automator.actions.web.wait.WaitUntilElementIsDisabledAction;

public class WaitUntilElementIsDisabledSnippet extends WaitUntilElementIsDisabledAction {
}
