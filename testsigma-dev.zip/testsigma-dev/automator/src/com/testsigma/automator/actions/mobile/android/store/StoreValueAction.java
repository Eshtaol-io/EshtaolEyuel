package com.testsigma.automator.actions.mobile.android.store;

public class StoreValueAction extends com.testsigma.automator.actions.web.store.StoreValueAction {
}
