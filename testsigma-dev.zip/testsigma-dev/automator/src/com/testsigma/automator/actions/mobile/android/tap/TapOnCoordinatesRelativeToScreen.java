package com.testsigma.automator.actions.mobile.android.tap;

public class TapOnCoordinatesRelativeToScreen extends com.testsigma.automator.actions.mobile.tap.TapOnCoordinatesRelativeToScreen {
}
