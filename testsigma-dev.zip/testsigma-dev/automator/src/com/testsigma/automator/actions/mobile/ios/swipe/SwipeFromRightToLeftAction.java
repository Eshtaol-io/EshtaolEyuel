package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromRightToLeftAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeRightToLeftSnippet {
}
