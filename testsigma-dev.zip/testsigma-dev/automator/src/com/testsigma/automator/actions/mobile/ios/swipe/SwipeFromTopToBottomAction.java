package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromTopToBottomAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeTopToBottomSnippet {
}
