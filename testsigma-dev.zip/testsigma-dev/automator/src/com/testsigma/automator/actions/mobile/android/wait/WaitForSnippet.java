package com.testsigma.automator.actions.mobile.android.wait;

import com.testsigma.automator.actions.common.WaitAction;

public class WaitForSnippet extends WaitAction {
}
