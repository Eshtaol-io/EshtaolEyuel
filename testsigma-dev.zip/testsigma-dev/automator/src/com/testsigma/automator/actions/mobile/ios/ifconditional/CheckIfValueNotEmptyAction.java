package com.testsigma.automator.actions.mobile.ios.ifconditional;

import com.testsigma.automator.actions.mobile.ios.verify.VerifyValueNotEmptyAction;

public class CheckIfValueNotEmptyAction extends VerifyValueNotEmptyAction {
}
