package com.testsigma.automator.actions.mobile.ios.wait;

public class WaitUntilElementIsEnabledAction extends com.testsigma.automator.actions.web.wait.WaitUntilElementIsEnabledAction {
}
