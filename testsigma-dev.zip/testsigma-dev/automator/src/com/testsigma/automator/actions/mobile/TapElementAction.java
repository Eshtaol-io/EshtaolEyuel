/*
 *
 * ****************************************************************************
 *  * Copyright (C) 2019 Testsigma Technologies Inc.
 *  * All rights reserved.
 *  ****************************************************************************
 *
 */

package com.testsigma.automator.actions.mobile;

import com.testsigma.automator.actions.mobile.tap.MobileNativeClickSnippet;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class TapElementAction extends MobileNativeClickSnippet {

//  @Override
//  public void execute() throws Exception {
//    findElement();
//    new TouchAction<>(getDriver()).tap(TapOptions.tapOptions().withElement(new ElementOption().withElement(getElement()))).perform();
//  }
}
