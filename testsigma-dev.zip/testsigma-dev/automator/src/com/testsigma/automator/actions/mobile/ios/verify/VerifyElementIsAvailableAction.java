package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyElementIsAvailableAction extends com.testsigma.automator.actions.web.verify.VerifyElementIsAvailableAction {
}
