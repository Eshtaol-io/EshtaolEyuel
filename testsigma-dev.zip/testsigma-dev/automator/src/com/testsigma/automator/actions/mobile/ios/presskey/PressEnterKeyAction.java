package com.testsigma.automator.actions.mobile.ios.presskey;

public class PressEnterKeyAction extends com.testsigma.automator.actions.mobile.press.PressEnterSnippet {
}
