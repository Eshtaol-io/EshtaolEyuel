package com.testsigma.automator.actions.mobile.android.enter;

public class EnterDataOnFocusedElement extends com.testsigma.automator.actions.mobile.enter.EnterDataOnFocusedElement {
}
