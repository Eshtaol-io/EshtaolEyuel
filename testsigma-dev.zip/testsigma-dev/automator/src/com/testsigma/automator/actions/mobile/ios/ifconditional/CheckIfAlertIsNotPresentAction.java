package com.testsigma.automator.actions.mobile.ios.ifconditional;

import com.testsigma.automator.actions.mobile.ios.alert.VerifyAlertAbsenceAction;

public class CheckIfAlertIsNotPresentAction extends VerifyAlertAbsenceAction {
}
