package com.testsigma.automator.actions.mobile.ios.generic;

import com.testsigma.automator.actions.mobile.MobileNativeOrientationLandscapeSnippet;

public class SetOrientationToLandscapeAction extends MobileNativeOrientationLandscapeSnippet {
}
