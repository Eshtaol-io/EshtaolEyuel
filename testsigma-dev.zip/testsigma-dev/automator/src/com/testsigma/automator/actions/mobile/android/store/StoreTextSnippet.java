package com.testsigma.automator.actions.mobile.android.store;

import com.testsigma.automator.actions.web.store.StoreTextAction;

public class StoreTextSnippet extends StoreTextAction {
}
