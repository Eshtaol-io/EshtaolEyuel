package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyTextAbsentAction;

public class CurrentPageTextAbsentAction extends VerifyTextAbsentAction {
}
