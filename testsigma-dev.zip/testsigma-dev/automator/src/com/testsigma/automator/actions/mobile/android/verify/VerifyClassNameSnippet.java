package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.web.verify.VerifyClassNameAction;

public class VerifyClassNameSnippet extends VerifyClassNameAction {
}
