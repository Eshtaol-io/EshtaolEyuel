package com.testsigma.automator.actions.mobile.ios.generic;

public class NavigateBackAction extends com.testsigma.automator.actions.common.NavigateBackAction {
}
