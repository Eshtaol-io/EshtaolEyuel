package com.testsigma.automator.actions.mobile.ios.store;

public class StoreElementAttributeAction extends com.testsigma.automator.actions.web.store.StoreElementAttributeAction {
}
