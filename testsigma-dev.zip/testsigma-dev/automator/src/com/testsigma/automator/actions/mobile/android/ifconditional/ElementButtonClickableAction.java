package com.testsigma.automator.actions.mobile.android.ifconditional;


import com.testsigma.automator.actions.mobile.android.verify.VerifyButtonIsClickableAction;

public class ElementButtonClickableAction extends VerifyButtonIsClickableAction {
}
