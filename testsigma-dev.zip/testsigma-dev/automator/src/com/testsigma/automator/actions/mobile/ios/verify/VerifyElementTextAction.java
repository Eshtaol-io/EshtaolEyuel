package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyElementTextAction extends com.testsigma.automator.actions.web.verify.VerifyElementTextAction {
}
