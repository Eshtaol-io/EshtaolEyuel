package com.testsigma.automator.actions.mobile.ios.store;

public class StoreElementsCountAction extends com.testsigma.automator.actions.web.store.StoreElementsCountAction {
}
