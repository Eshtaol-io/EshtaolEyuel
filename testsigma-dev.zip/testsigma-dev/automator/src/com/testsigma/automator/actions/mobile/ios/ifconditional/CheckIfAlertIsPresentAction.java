package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyAlertPresentAction;

public class CheckIfAlertIsPresentAction extends VerifyAlertPresentAction {
}
