package com.testsigma.automator.actions.mobile.ios.ifconditional;

import com.testsigma.automator.actions.mobile.ios.verify.VerifyElementPresenceAction;

public class CurrentPageDisplaysElementAction extends VerifyElementPresenceAction {
}
