package com.testsigma.automator.actions.mobile.mobileweb;

import com.testsigma.automator.actions.web.generic.GetTextFromElementAction;

public class GetTextFromAction extends GetTextFromElementAction {
}
