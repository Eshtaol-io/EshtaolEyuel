package com.testsigma.automator.actions.mobile.ios.tap;

public class TapOnCoordinatesRelativeToScreen extends com.testsigma.automator.actions.mobile.tap.TapOnCoordinatesRelativeToScreen {
}
