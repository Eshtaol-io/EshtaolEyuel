package com.testsigma.automator.actions.mobile.mobileweb.check;

import com.testsigma.automator.actions.web.checkbox.SelectCheckBoxAction;

public class CheckAction extends SelectCheckBoxAction {
}
