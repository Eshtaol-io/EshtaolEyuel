package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyAttributeValueContainsAction extends com.testsigma.automator.actions.web.verify.VerifyAttributeValueContainsAction {
}
