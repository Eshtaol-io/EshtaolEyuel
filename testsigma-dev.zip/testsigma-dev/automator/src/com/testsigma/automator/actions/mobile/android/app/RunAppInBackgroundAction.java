package com.testsigma.automator.actions.mobile.android.app;

public class RunAppInBackgroundAction extends com.testsigma.automator.actions.mobile.app.RunAppInBackgroundAction {
}
