package com.testsigma.automator.actions.mobile.android.tap;

import com.testsigma.automator.actions.mobile.TapElementAction;

public class TapOnElement extends TapElementAction {
}
