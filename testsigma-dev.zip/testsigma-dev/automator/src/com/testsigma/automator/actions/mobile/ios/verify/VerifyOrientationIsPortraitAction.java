package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyOrientationIsPortraitAction extends com.testsigma.automator.actions.mobile.verify.VerifyOrientationIsPortraitSnippet {
}
