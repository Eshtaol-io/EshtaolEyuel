package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyAttributeValueAction;

public class ElementHasAttributeValueAction extends VerifyAttributeValueAction {
}
