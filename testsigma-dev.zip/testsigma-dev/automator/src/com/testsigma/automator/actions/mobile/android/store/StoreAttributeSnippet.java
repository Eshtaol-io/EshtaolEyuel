package com.testsigma.automator.actions.mobile.android.store;

import com.testsigma.automator.actions.web.store.StoreElementAttributeAction;

public class StoreAttributeSnippet extends StoreElementAttributeAction {
}
