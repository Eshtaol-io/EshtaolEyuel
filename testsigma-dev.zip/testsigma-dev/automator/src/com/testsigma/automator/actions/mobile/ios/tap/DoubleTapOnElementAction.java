package com.testsigma.automator.actions.mobile.ios.tap;

public class DoubleTapOnElementAction extends com.testsigma.automator.actions.mobile.tap.DoubleTapOnElementAction {
}
