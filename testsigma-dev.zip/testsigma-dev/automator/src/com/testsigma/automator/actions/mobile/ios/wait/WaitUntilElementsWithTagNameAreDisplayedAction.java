package com.testsigma.automator.actions.mobile.ios.wait;


public class WaitUntilElementsWithTagNameAreDisplayedAction extends com.testsigma.automator.actions.web.wait.WaitUntilElementsWithTagNameAreDisplayedAction {
}
