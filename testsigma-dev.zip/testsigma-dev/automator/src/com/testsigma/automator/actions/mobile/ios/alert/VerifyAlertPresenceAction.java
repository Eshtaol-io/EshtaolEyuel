package com.testsigma.automator.actions.mobile.ios.alert;

public class VerifyAlertPresenceAction extends com.testsigma.automator.actions.web.verify.VerifyAlertPresenceAction {
}
