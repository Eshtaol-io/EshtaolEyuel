package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.web.verify.VerifyElementAbsenceAction;

public class VerifyElementAbsentSnippet extends VerifyElementAbsenceAction {
}
