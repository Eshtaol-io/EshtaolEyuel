package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyElementEnabledAction extends com.testsigma.automator.actions.web.verify.VerifyElementEnabledAction {
}
