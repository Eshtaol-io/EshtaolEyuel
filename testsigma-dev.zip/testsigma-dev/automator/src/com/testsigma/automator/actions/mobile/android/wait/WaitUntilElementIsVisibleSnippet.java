package com.testsigma.automator.actions.mobile.android.wait;

import com.testsigma.automator.actions.web.wait.WaitUntilElementIsVisibleAction;

public class WaitUntilElementIsVisibleSnippet extends WaitUntilElementIsVisibleAction {
}
