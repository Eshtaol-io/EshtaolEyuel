package com.testsigma.automator.actions.mobile.ios.enter;

public class EnterDataOnFocusedElement extends com.testsigma.automator.actions.mobile.enter.EnterDataOnFocusedElement {
}
