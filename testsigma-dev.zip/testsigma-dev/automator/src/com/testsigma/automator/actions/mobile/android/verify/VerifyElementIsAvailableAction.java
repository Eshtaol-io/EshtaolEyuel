package com.testsigma.automator.actions.mobile.android.verify;

public class VerifyElementIsAvailableAction extends com.testsigma.automator.actions.web.verify.VerifyElementIsAvailableAction {
}
