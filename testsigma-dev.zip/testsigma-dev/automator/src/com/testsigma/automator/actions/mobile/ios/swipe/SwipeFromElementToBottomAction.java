package com.testsigma.automator.actions.mobile.ios.swipe;


public class SwipeFromElementToBottomAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeElementToBottomSnippet {
}
