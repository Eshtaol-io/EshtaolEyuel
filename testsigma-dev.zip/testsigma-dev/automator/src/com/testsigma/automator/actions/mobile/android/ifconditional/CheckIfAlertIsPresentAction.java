package com.testsigma.automator.actions.mobile.android.ifconditional;

import com.testsigma.automator.actions.mobile.android.verify.VerifyAlertPresentAction;

public class CheckIfAlertIsPresentAction extends VerifyAlertPresentAction {
}
