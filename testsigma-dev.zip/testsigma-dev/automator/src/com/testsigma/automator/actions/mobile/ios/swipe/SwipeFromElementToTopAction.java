package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromElementToTopAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeElementToTopSnippet {
}
