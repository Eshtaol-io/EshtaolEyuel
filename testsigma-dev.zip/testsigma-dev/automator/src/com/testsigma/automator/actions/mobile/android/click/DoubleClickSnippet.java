package com.testsigma.automator.actions.mobile.android.click;

import com.testsigma.automator.actions.web.click.DoubleClickOnElementAction;

public class DoubleClickSnippet extends DoubleClickOnElementAction {
}
