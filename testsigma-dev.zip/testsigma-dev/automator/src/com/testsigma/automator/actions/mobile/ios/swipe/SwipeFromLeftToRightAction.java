package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromLeftToRightAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeLeftToRightSnippet {
}
