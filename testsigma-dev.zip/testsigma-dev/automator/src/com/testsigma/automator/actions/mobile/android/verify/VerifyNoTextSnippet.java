package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.web.verify.VerifyTextNotPresentInElementAction;

public class VerifyNoTextSnippet extends VerifyTextNotPresentInElementAction {
}
