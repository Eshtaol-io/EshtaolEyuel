package com.testsigma.automator.actions.mobile.android.store;

import com.testsigma.automator.actions.web.store.StoreElementsCountAction;

public class StoreElementsCountSnippet extends StoreElementsCountAction {
}
