package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyElementsCountAction extends com.testsigma.automator.actions.web.verify.VerifyElementsCountAction {
}
