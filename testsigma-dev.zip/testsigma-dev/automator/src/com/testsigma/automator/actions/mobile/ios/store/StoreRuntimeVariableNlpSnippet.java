package com.testsigma.automator.actions.mobile.ios.store;

public class StoreRuntimeVariableNlpSnippet extends com.testsigma.automator.actions.web.store.StoreRuntimeVariableNlpSnippet {
}
