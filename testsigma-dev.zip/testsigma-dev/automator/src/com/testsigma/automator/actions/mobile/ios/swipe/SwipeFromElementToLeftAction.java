package com.testsigma.automator.actions.mobile.ios.swipe;


public class SwipeFromElementToLeftAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeElementToLeftSnippet {
}
