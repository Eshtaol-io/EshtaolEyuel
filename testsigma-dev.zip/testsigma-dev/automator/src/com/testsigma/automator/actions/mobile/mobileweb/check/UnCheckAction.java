package com.testsigma.automator.actions.mobile.mobileweb.check;

import com.testsigma.automator.actions.web.checkbox.UnCheckCheckboxAction;

public class UnCheckAction extends UnCheckCheckboxAction {
}
