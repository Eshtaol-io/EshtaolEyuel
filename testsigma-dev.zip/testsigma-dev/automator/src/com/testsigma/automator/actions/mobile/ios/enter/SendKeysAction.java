package com.testsigma.automator.actions.mobile.ios.enter;

public class SendKeysAction extends com.testsigma.automator.actions.common.SendKeysAction {
}
