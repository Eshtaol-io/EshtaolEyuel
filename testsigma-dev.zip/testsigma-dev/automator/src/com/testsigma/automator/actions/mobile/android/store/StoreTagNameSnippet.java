package com.testsigma.automator.actions.mobile.android.store;

import com.testsigma.automator.actions.web.store.StoreTagNameAction;

public class StoreTagNameSnippet extends StoreTagNameAction {
}
