package com.testsigma.automator.actions.mobile.android.click;

import com.testsigma.automator.actions.mobile.mobileweb.click.ClickLocatorWithTextContainsAction;

public class ClickLocatorWithTextContainsSnippet extends ClickLocatorWithTextContainsAction {
}
