package com.testsigma.automator.actions.mobile.android.verify;

public class VerifyElementCountEqualsSnippet extends com.testsigma.automator.actions.web.verify.VerifyElementsCountAction {
}
