package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromBottomToTopAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeBottomToTopSnippet {
}
