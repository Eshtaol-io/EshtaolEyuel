package com.testsigma.automator.actions.mobile.android.generic;

import com.testsigma.automator.actions.web.generic.ClearDataAction;

public class ClearSnippet extends ClearDataAction {
}
