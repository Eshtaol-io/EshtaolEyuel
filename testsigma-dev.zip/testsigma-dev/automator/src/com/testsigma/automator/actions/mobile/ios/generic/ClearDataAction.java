package com.testsigma.automator.actions.mobile.ios.generic;

public class ClearDataAction extends com.testsigma.automator.actions.web.generic.ClearDataAction {
}
