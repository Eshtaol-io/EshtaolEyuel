package com.testsigma.automator.actions.mobile.loopactions;

public class BreakLoop extends com.testsigma.automator.actions.web.loopactions.BreakLoop {

}
