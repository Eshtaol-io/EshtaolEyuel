package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyElementDisabledAction extends com.testsigma.automator.actions.web.verify.VerifyElementDisabledAction {
}
