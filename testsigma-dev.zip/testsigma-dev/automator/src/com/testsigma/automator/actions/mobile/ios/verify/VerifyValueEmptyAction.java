package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyValueEmptyAction extends com.testsigma.automator.actions.web.verify.VerifyValueEmptyAction {
}
