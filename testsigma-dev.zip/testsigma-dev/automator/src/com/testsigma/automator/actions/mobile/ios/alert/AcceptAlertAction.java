package com.testsigma.automator.actions.mobile.ios.alert;

public class AcceptAlertAction extends com.testsigma.automator.actions.web.generic.AcceptAlertAction {
}
