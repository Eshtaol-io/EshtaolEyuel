package com.testsigma.automator.actions.mobile.android.click;

import com.testsigma.automator.actions.mobile.mobileweb.click.ClickLocatorWithTextAction;

public class ClickLocatorWithTextSnippet extends ClickLocatorWithTextAction {
}
