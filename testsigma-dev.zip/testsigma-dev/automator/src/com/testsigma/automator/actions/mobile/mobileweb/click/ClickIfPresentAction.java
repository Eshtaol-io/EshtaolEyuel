package com.testsigma.automator.actions.mobile.mobileweb.click;

import com.testsigma.automator.actions.web.click.ClickIfDisplayedAction;

public class ClickIfPresentAction extends ClickIfDisplayedAction {

}
