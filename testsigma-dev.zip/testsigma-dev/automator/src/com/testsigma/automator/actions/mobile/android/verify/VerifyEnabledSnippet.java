package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.web.verify.VerifyElementEnabledAction;

public class VerifyEnabledSnippet extends VerifyElementEnabledAction {
}
