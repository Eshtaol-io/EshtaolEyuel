package com.testsigma.automator.actions.mobile.ios.store;

public class StoreTextAction extends com.testsigma.automator.actions.web.store.StoreTextAction {
}
