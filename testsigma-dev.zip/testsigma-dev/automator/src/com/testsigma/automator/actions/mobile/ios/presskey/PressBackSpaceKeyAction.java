package com.testsigma.automator.actions.mobile.ios.presskey;

public class PressBackSpaceKeyAction extends com.testsigma.automator.actions.mobile.press.PressBackSpaceSnippet {
}
