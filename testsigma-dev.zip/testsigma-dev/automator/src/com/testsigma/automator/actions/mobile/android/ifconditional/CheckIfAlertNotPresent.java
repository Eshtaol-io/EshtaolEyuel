package com.testsigma.automator.actions.mobile.android.ifconditional;

import com.testsigma.automator.actions.mobile.android.verify.VerifyAlertAbsenceAction;

public class CheckIfAlertNotPresent extends VerifyAlertAbsenceAction {
}
