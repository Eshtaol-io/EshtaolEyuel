package com.testsigma.automator.actions.mobile.ios.presskey;

public class PressSpaceKeyAction extends com.testsigma.automator.actions.mobile.press.PressSpaceSnippet {
}
