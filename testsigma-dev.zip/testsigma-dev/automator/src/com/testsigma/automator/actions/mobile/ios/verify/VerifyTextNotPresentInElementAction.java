package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyTextNotPresentInElementAction extends com.testsigma.automator.actions.web.verify.VerifyTextNotPresentInElementAction {
}
