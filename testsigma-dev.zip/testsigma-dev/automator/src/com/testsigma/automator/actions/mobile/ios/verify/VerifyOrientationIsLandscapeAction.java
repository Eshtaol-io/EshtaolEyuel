package com.testsigma.automator.actions.mobile.ios.verify;


public class VerifyOrientationIsLandscapeAction extends com.testsigma.automator.actions.mobile.verify.VerifyOrientationIsLandscapeSnippet {
}
