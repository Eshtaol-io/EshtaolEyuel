package com.testsigma.automator.actions.mobile.android.wait;

import com.testsigma.automator.actions.web.wait.WaitUntilElementsWithClassNameAreDisplayedAction;

public class WaitUntilAllElementsOfClassNameAreDisplayedSnippet extends WaitUntilElementsWithClassNameAreDisplayedAction {
}
