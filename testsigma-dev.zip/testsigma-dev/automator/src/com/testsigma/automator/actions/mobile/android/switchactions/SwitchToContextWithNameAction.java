package com.testsigma.automator.actions.mobile.android.switchactions;

import com.testsigma.automator.actions.mobile.switchactions.MobileNativeSwitchToContextWithNameAction;

public class SwitchToContextWithNameAction extends MobileNativeSwitchToContextWithNameAction {

}
