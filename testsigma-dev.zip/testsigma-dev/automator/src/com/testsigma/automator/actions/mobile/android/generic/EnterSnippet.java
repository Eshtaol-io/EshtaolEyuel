package com.testsigma.automator.actions.mobile.android.generic;

import com.testsigma.automator.actions.common.SendKeysAction;

public class EnterSnippet extends SendKeysAction {
}
