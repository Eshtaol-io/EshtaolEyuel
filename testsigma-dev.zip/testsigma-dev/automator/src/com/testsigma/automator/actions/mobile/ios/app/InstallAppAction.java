package com.testsigma.automator.actions.mobile.ios.app;

import com.testsigma.automator.actions.mobile.MobileNativeInstallAppSnippet;

public class InstallAppAction extends MobileNativeInstallAppSnippet {
}
