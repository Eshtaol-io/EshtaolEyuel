package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyElementsCountGreaterOrEqualsAction extends com.testsigma.automator.actions.web.verify.VerifyElementsCountGreaterOrEqualsAction {
}
