package com.testsigma.automator.actions.mobile.ios.tap;

public class TapOnElementAction extends com.testsigma.automator.actions.mobile.tap.MobileNativeClickSnippet {
}
