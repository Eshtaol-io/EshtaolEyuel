package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyTitleContainsAction;

public class TitleContainsAction extends VerifyTitleContainsAction {
}
