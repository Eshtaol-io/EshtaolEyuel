package com.testsigma.automator.actions.mobile.ios.presskey;

public class PressTestDataKeyAction extends com.testsigma.automator.actions.mobile.press.PressKeySnippet {
}
