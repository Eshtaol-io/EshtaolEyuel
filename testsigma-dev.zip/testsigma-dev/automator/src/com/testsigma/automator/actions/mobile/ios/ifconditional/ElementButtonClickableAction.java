package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyButtonIsClickableAction;

public class ElementButtonClickableAction extends VerifyButtonIsClickableAction {
}
