package com.testsigma.automator.actions.mobile.android.tap;

public class TapOnElementUsingCoordinatesAction extends com.testsigma.automator.actions.mobile.tap.TapOnElementUsingCoordinatesAction {
}
