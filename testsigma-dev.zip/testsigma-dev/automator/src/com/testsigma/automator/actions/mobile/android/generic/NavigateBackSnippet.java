package com.testsigma.automator.actions.mobile.android.generic;

import com.testsigma.automator.actions.common.NavigateBackAction;

public class NavigateBackSnippet extends NavigateBackAction {
}
