package com.testsigma.automator.actions.mobile.ios.alert;

public class VerifyAlertTextAction extends com.testsigma.automator.actions.web.verify.VerifyAlertTextAction {
}
