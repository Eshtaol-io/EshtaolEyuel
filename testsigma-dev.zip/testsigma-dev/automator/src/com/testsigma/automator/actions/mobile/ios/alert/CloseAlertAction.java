package com.testsigma.automator.actions.mobile.ios.alert;

import com.testsigma.automator.actions.web.generic.CancelAlertAction;

public class CloseAlertAction extends CancelAlertAction {
}
