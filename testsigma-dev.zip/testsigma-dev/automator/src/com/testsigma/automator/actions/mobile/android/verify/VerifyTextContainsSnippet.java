package com.testsigma.automator.actions.mobile.android.verify;

import com.testsigma.automator.actions.web.verify.VerifyElementTextContainsAction;

public class VerifyTextContainsSnippet extends VerifyElementTextContainsAction {
}
