package com.testsigma.automator.actions.mobile.ios.app;

public class RunAppInBackgroundAction extends com.testsigma.automator.actions.mobile.app.RunAppInBackgroundAction {
}

