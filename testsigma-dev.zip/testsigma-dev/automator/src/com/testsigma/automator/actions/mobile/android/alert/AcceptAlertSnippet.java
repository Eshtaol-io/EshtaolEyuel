package com.testsigma.automator.actions.mobile.android.alert;

import com.testsigma.automator.actions.web.generic.AcceptAlertAction;

public class AcceptAlertSnippet extends AcceptAlertAction {
}
