package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyElementTextAction;

public class ElementHasTextAction extends VerifyElementTextAction {
}
