package com.testsigma.automator.actions.mobile.android.generic;

public class DragAndDropAction extends com.testsigma.automator.actions.mobile.generic.DragAndDropAction {
}
