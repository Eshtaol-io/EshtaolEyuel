package com.testsigma.automator.actions.mobile.android.ifconditional;


import com.testsigma.automator.actions.mobile.android.verify.VerifyAttributeSnippet;

public class ElementHasAttributeValueAction extends VerifyAttributeSnippet {
}
