package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromMiddleToRightAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeMiddleToRightSnippet {
}
