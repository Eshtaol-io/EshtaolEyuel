package com.testsigma.automator.actions.mobile.ios.wait;

public class WaitUntilElementIsVisibleAction extends com.testsigma.automator.actions.web.wait.WaitUntilElementIsVisibleAction {
}
