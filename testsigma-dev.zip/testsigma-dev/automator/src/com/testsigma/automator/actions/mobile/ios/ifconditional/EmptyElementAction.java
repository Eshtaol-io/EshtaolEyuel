package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyValueEmptyAction;

public class EmptyElementAction extends VerifyValueEmptyAction {
}
