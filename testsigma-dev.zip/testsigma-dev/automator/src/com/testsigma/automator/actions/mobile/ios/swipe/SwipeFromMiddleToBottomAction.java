package com.testsigma.automator.actions.mobile.ios.swipe;

public class SwipeFromMiddleToBottomAction extends com.testsigma.automator.actions.mobile.swipe.MobileNativeSwipeMiddleToBottomSnippet {
}
