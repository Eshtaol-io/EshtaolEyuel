package com.testsigma.automator.actions.mobile.ios.switchactions;

import com.testsigma.automator.actions.mobile.switchactions.MobileNativeSwitchToWebviewAction;

public class SwitchToWebviewAction extends MobileNativeSwitchToWebviewAction {
}
