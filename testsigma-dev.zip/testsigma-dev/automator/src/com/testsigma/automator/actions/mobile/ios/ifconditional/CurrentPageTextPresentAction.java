package com.testsigma.automator.actions.mobile.ios.ifconditional;


import com.testsigma.automator.actions.mobile.ios.verify.VerifyTextPresentAction;

public class CurrentPageTextPresentAction extends VerifyTextPresentAction {
}
