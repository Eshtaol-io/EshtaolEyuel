package com.testsigma.automator.actions.mobile.ios.verify;

public class VerifyIfAppInstalledAction extends com.testsigma.automator.actions.mobile.verify.VerifyIfAppInstalledAction {

}
