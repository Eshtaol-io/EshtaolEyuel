package com.testsigma.automator.actions.mobile.android.switchactions;

import com.testsigma.automator.actions.mobile.switchactions.MobileNativeSwitchToWebviewAction;

public class SwitchToWebviewContextAction extends MobileNativeSwitchToWebviewAction {

}
