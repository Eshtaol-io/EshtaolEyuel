package com.testsigma.automator.actions.mobile.android.ifconditional;

import com.testsigma.automator.actions.mobile.android.verify.VerifyValueNotEmptyAction;

public class CheckIfValueNotEmptyAction extends VerifyValueNotEmptyAction {
}
