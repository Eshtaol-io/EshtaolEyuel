package com.testsigma.automator.actions.mobile.ios.store;

public class StoreValueAction extends com.testsigma.automator.actions.web.store.StoreValueAction {
}
