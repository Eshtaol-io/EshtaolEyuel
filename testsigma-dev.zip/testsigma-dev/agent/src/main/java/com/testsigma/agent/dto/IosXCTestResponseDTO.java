package com.testsigma.agent.dto;

import lombok.Data;

@Data
public class IosXCTestResponseDTO {
    String xcTestRemoteUrl;
}
