package com.testsigma.agent.dto;

import lombok.Data;

@Data
public class IosDeveloperImageDTO {
  String developerImageUrl;
  String developerImageSignatureUrl;
}
