package com.testsigma.agent.mobile.ios;

import com.testsigma.agent.exception.TestsigmaException;

public class UsbMuxException extends TestsigmaException {
  public UsbMuxException(String message, Exception cause) {
    super(message, cause);
  }
}
