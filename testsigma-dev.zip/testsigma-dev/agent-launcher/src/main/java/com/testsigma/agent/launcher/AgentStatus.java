package com.testsigma.agent.launcher;

public enum AgentStatus {
  STARTING,
  STARTED,
  STOPPING,
  STOPPED
}
